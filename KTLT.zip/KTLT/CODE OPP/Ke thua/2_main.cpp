#include "2_Employee.cpp"
#include "2_Manager.cpp"
#include <iostream>
using namespace std;

int main(){
    Employee e1("Quang Vinh", 2000);
    e1.display();
    
    return 0;
}