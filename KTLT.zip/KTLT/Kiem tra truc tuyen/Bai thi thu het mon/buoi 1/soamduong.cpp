#include <iostream>
using namespace std;


int main() {
    int n; cin >> n;
    int a[n];
    for (int i = 0; i < n; i++) {
        cin >> a[i];
    }
    int ca = 0, cd = 0;
    for (int i = 0; i < n; i++) {
        if (a[i] < 0) ca++;
        if (a[i] > 0) cd++;
    }
    cout << cd << " " << ca;
    return 0;
}